from processamento import Processamento
from datetime import datetime, timedelta
import sys
from log import Log
from time import sleep
from banco_operacoes import Operacoes
import socket
from manipular_hubspot import ManipularHubspot
import os
import ctypes


print("Inicializando...")
global proc, main
parametros = sys.argv
ambiente = ''
acao = ''
if len(parametros) != 1:
    ambiente = parametros[1]
    if ambiente not in ('hml', 'prod'):
        print(f"Parâmetro '{ambiente}' não corresponde a um ambiente válido. Ex.: hml ou prod")
        sleep(15)
        sys.exit(1)
    if len(parametros) > 2:
        if parametros[2] in ("input", "input+", "importacao", "atualizacao", "importacao_input", "icconsig"):
            acao = parametros[2]
    else:
        acao = "consulta"

mensagem = f"""* * * ITAÚ SAQUE ANIVERSÁRIO FGTS * * *
Ambiente de {'Produção' if ambiente == 'prod' else 'Homologação'}
MODO: {acao.upper() + ("" if acao.__contains__("input") else " - ELEGIBILIDADE") + (" IMPORTAÇÃO" if acao.__contains__("+") else "")}
"""
os.system("cls")
print(mensagem)
sleep(3)


class Main:

    def __init__(self):
        try:
            self.tentativa = 0
            self.db = Operacoes(ambiente)
            self.log = Log(ambiente)
            self.hostname = socket.gethostname()
            self.hubspot = ManipularHubspot(ambiente)
            self.info = self.db.obter_info_projeto()[0]
            self.__arquivoLog = f"""log_{self.info['nome']}.txt"""
            if os.path.isfile(self.__arquivoLog):
                os.remove(self.__arquivoLog)
                open(self.__arquivoLog, "w+")

        except Exception as e:
            raise Exception(e)

    def verificar_execucao(self, erro):
        self.log.logar_mensagem(f'>>> verificar_execucao(erro={erro})')
        self.tentativa += 1
        if acao.__contains__("input") or acao.__contains__("consulta"):
            proc.efetuar_logout()
        proc.enviar_email(str(erro), True)
        sleep(proc.obter_espera(str(erro)))

        # print(f"* * * * * * Tentativa #{self.tentativa} * * * * * *")
        # if self.tentativa > 3:
        #     self.tentativa = 0
        #     proc.enviar_email(erro, True)
        #     sleep(3600)  # 1 hora

    def processar_icconsig(self):
        self.log.logar_mensagem(f'>>> processar_icconsig()')
        qtde_registros = self.db.obter_registro_icconsig(main.hostname)
        if qtde_registros:
            proc_icconsig = Processamento(ambiente, "chrome", True)
            proc_icconsig.processar_registros_icconsig(qtde_registros)

    def desconectar_usuario(self):
        # self.log.logar_mensagem(f'>>> desconectar_usuario()')
        try:
            if not any(parametro in "monitor" for parametro in parametros):
                self.minimizar_console()
                if acao == "input":
                    if self.hostname.__contains__("AWS"):
                        os.system(r'''
                            Powershell -Command "& { Start-Process \"C:\\RPA\\AlwaysOn.bat\" -WindowStyle Minimized -ArgumentList @(\"C:\\Windows\\System32\\drivers\\etc\\hosts\") -Verb RunAs } "
                        ''')
        except Exception as e:
            self.log.logar_mensagem(e)

    def minimizar_console(self):
        try:
            ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 6)
        except:
            pass


while True:
    try:
        main = Main()
        main.desconectar_usuario()
        os.system("cls")
        break
    except Exception as e:
        print(f"Erro ao inicializar main: {e}")
        agora = datetime.now()
        reinicio = agora + timedelta(minutes=15)
        espera = int((reinicio - agora).total_seconds())
        print(f"       Parada em: {agora}\nPróxima execução: {reinicio} ({espera}s)")
        sleep(espera)

if acao == "importacao":
    pass
elif acao == "atualizacao":
    pass
elif acao == "importacao_input":
    try:
        while True:
            os.system('cls')
            print(mensagem)
            main.minimizar_console()
            main.hubspot.importar_input()
            print("Aguardando por 5 minutos")
            sleep(5*60)
    except Exception as e:
        main.log.logar_mensagem(e, True, "ERRO")
        main.verificar_execucao(e)

elif acao == "icconsig":
    try:
        registro = main.db.obter_registro_icconsig(main.hostname)
        while registro:
            proc = Processamento(ambiente, "chrome", True)
            proc.processar_registros_icconsig()
            registro = main.db.obter_registro_icconsig(main.hostname)
            sleep(5*60)
            print("Aguardando por 5 minutos")
    except Exception as e:
        main.log.logar_mensagem(e, True, "ERRO")
        main.verificar_execucao(e)

else:
    input = acao.__contains__("input")
    while True:
        os.system('cls')
        print(mensagem)
        try:
            if acao == "input+":
                main.hubspot.importar_input()

            main.processar_icconsig()

            retorno = ""
            if main.db.verificar_registros(main.hostname, input):
                main.db.limpar_registros(main.hostname, input)
                proc = Processamento(ambiente, "ie" if input else "chrome", input)

                # espera = proc.verificar_horario(input)
                # sleep(espera)
                proc.efetuar_login()
                if input:
                    retorno = proc.processar_registros_input()
                else:
                    retorno = proc.processar_registros()
                if retorno != "OK":
                    proc.enviar_email(str(retorno), True)
                proc.efetuar_logout()
            else:
                os.system('cls')
                # espera = proc.verificar_horario(input)
                print("Sem registros para processar.\n\n")

                agora = datetime.now()
                reinicio = agora + timedelta(minutes=5)
                espera = int((reinicio - agora).total_seconds())
                print(f"       Parada em: {agora}\nPróxima execução: {reinicio} ({espera}s)")
                sleep(espera)

            main.processar_icconsig()

        except Exception as e:
            main.log.logar_mensagem(e, True, "ERRO")
            if proc:
                main.verificar_execucao(e)
        finally:
            pass
